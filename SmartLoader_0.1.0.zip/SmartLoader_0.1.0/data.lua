require "util"
--here the entity of new inserter will be defined
--i'm lazy bastard, so it'll just copy ordinary smart inserter
local smart=table.deepcopy(data.raw.inserter['smart-inserter'])
smart.name='smart-loader';
    local icon='__SmartLoader__/icon.png'
smart.icon=icon;
smart.minable.result='smart-loader';
    local tint={r=238/255, g=130/255, b=238/255, a=1}
smart.hand_base_picture.tint=tint;
smart.hand_closed_picture.tint=tint;
smart.hand_open_picture.tint=tint;
smart.platform_picture.sheet.tint=tint;
smart.filter_count=0;
--item for it
local item=  {
    type = "item",
    name = "smart-loader",
    icon = icon,
    flags = {"goes-to-quickbar"},
    subgroup = "inserter",
    order = "f[inserter]-e[smart-inserter]",
    place_result = "smart-loader",
    stack_size = 50
    }
--recipe to make
local recipe=  {
    type = "recipe",
    name = "smart-loader",
    enabled = false,
    ingredients =
    {
      {"fast-inserter", 1},
      {"electronic-circuit", 1}
    },
    result = "smart-loader"
  }
--tech to unlock
local tech={
    type = "technology",
    name = "smart-loading",
    icon = icon,--same crappy icon everywhere, lazy bastard indeed
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "smart-loader"
      }
    },
    prerequisites = {"electronics","automated-rail-transportation"},
    unit =
    {
      count = 50,
      ingredients = {{"science-pack-1", 1},{"science-pack-2", 1}},
      time = 20
    },
    order = "a-d-a",
  }
data:extend({tech,recipe,item,smart})
