--We will keep track of every smart loader
--on entity built we'll check whether it's smart loader
--each loader will be checked once in three seconds
--if it's imposible to put entity into it's target, we'll rotate it back to source
--a few ticks later we'll return it's orientation to normal
--we won't check if inserter is placing items onto empty ground
--if it fails to put there as well, we'll just wait till next check up
--yes the code here is rather sloppy and update times may get stirred by player actions 
--but their accuracy is not critical for the matter at hand
require "defines"
require "util"
interval=3*60


function init() 
    global.loaders=global.loaders or {}; 
    global.next_check=global.next_check or game.tick+interval;
    global.next_rotation=global.next_rotation or 0
    global.initial=global.initial or 1
    global.rotate=global.rotate or {}
end
game.on_init(function() init() end)
game.on_load(function() init() end)

game.on_event({defines.events.on_built_entity,defines.events.on_robot_built_entity},
    function(event)
        if event.created_entity.name=='smart-loader' then
            table.insert(global.loaders,event.created_entity)
            if #global.loaders==1 then 
                global.next_check=game.tick+interval
                global.initial=1;
            end
        end
    end)

game.on_event(defines.events.on_tick, 
    function(event)
        if event.tick==global.next_rotation then
            for i,loader in ipairs(global.rotate) do
                if event.tick==loader.tick then
                    loader.entity.direction=util.oppositedirection(loader.entity.direction)
                    table.remove(global.rotate,i)
                    global.next_rotation=(global.rotate[1] and global.rotate[1].tick) or 0
                end
            end
        end
        if event.tick~=global.next_check then return end
        --game.player.print('checking')
        for i=global.initial,#global.loaders,interval do
            --game.player.print(i)
            local loader=global.loaders[i];
            if loader.drop_target and loader.held_stack.valid_for_read and not loader.drop_target.can_insert(loader.held_stack) then
                --loader.surface.create_entity{name='flying-text',position=loader.position,text='nope'}
                loader.direction=util.oppositedirection(loader.direction)
                table.insert(global.rotate,{tick=event.tick+20,entity=loader})
                global.next_rotation=global.rotate[1].tick
            end
        end
        global.initial=(global.initial)%#global.loaders+1;
        if #global.loaders<interval then
            global.next_check=global.next_check+math.floor(interval/(#global.loaders))
        else
            global.next_check=1
        end
        --game.player.print('next check ' .. global.next_check)
        --game.player.print('next rotation ' .. global.next_rotation)
    end)
    
game.on_event({defines.events.on_entity_died,defines.events.on_robot_pre_mined_item,defines.events.on_preplayer_mined_item,},
    function(event)
    --game.player.print('destroy')
        if event.entity.name=='smart-loader' then
            i=1;
            while i<=#global.loaders and not(event.entity==global.loaders[i]) do
                i=i+1;
            end
            if i<=#global.loaders then 
                table.remove(global.loaders,i); 
                --game.player.print('yes') 
            end
        end
    end)
