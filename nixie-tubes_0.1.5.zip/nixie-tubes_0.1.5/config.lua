require 'defines'

debug_mode = false