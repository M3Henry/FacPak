data:extend({
    {
        type = "recipe",
        name = "upgrade-planner",
        energy_required = 1,
        ingredients = {
            { "advanced-circuit", 1 }
        },
        result = "upgrade-planner",
        enabled = "false"
    }
})
