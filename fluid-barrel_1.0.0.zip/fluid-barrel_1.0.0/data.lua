require("prototypes.item.fluid-barrel")

require("prototypes.recipe.fluid-barrel")

require("prototypes.technology.fluid-barrel")