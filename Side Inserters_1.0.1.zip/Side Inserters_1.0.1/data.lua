-- Side inserters have a shoter distance to travel, slowing down to compensate
SIDE_SPEED_FACTOR = 0.70

require("prototypes.entities")
require("prototypes.items")
require("prototypes.recipes")
require("prototypes.technology")