data:extend({
  {
    type = "recipe",
    name = "small-manufacturing-unit",
    enabled = "true",
    ingredients =
    {
      {"stone-brick", 5},
      {"iron-gear-wheel", 6},
      {"iron-plate", 4}
    },
    result = "small-manufacturing-unit"
  },
})
