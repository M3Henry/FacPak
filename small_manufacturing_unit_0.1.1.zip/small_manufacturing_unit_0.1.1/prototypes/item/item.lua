data:extend({
  {
    type = "item",
    name = "small-manufacturing-unit",
    icon = "__small_manufacturing_unit__/graphics/icons/small-manufacturing-unit.png",
    flags = {"goes-to-quickbar"},
    subgroup = "production-machine",
	order = "a-a-a",
    place_result = "small-manufacturing-unit",
    stack_size = 50
  },
})
