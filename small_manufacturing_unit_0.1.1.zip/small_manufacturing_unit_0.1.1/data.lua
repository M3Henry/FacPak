----ASSEMBLING MACHINES----
----Entity----
require("prototypes.entity.entity")
----Item----
require("prototypes.item.item")
----Recipe----
require("prototypes.recipe.recipe")