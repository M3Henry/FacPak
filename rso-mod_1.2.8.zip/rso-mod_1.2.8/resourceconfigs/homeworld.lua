function fillHomeworldConfig()
	config["sand"] = {
		type="resource-ore",
		
		allotment=50,
		spawns_per_region={min=1, max=2},
		richness=11000,
		size={min=12, max=18},
		min_amount=250,

		starting={richness=6000, size=14, probability=1},
		
		multi_resource_chance=0.50,
		multi_resource={
			["coal"] = 4,
			["crude-oil"] = 2,
			["iron-ore"] = 3,
			['copper-ore'] = 3,
		}
	}
end