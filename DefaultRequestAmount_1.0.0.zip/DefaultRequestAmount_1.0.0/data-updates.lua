local defaultAmount = 1

for name,list in pairs(data.raw) do
	for index,item in pairs(list) do
		if item.stack_size ~= nil then
			item.default_request_amount = defaultAmount
		end
	end
end
